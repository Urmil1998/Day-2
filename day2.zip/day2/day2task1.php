<?php
echo "Welcome to php";
echo "<h1>I am in 1st block of php</h1>";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Day2 Task1</title>
</head>
<body>
	<?php
		echo "I am Urmil Pancholi";
		echo "<h1>I am in Html block</h1>";
	?>
</body>
</html>