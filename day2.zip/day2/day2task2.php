<?php
$a=20;
$b=10;
echo "a is:".$a."<br>"."b is:".$b."<br>";
echo "sum is ".($a+$b);
?>