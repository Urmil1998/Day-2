<?php
	$a = 10;
	//if block start
	if($a==10){
		echo "a is equals to 10";
	}
	else if($a<10){
		echo "a is < 10";
	}
	else{
		echo "a is > 10";
	}
?>