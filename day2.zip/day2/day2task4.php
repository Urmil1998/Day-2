<?php
	$a=1;
	//switch case start
	switch($a)
	{
		case 1:echo "A is 1";
			break;
		case 2:echo "A is 2";
			break;
		default:echo "Wrong choice";
			break;
	}
?>